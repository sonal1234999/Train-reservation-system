package com.sid.model;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Seat {
	@Id
	int seatid;
	int trainid;
	int seatnumber;

	public Seat(int seatid, int trainid, int seatnumber) {
		super();
		this.seatid = seatid;
		this.trainid = trainid;
		this.seatnumber = seatnumber;
	}

	public int getSeatid() {
		return seatid;
	}

	public void setSeatid(int seatid) {
		this.seatid = seatid;
	}

	public int getTrainid() {
		return trainid;
	}

	public void setTrainid(int trainid) {
		this.trainid = trainid;
	}

	public int getSeatnumber() {
		return seatnumber;
	}

	public void setSeatnumber(int seatnumber) {
		this.seatnumber = seatnumber;
	}

}
