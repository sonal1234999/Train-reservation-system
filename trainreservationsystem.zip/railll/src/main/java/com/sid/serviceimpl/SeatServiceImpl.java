package com.sid.serviceimpl;

public class SeatServiceImpl implements SeatService{

}
