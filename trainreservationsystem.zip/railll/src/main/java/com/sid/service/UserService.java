package com.sid.service;

import java.util.List;

import com.sid.model.User;

public interface UserService {

	User createUser(User user);

	List<User> getAllUsers();

	User getUser(int uid);

	User updateUser(int userid, User user);

	String deleteUser(int userid);
}
