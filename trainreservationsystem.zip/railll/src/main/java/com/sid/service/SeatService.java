package com.sid.service;

import com.sid.model.Seat;

public class SeatService {

	Seat createSeat(Seat seat) {
		return null;
	}

	Seat getTrain(int seatId) {
		return null;
	}

	Seat updateSeat(String SeatId, Seat Seat) {
		return null;
	}

	Seat deleteSeat(String seatId) {
		return null;
	}

}
