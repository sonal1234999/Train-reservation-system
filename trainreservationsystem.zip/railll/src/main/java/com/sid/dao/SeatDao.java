package com.sid.dao;

import java.util.List;

import com.sid.model.Seat;

public interface SeatDao {
	Seat getSeatById(String seatId);

	List<Seat> getSeatsByTrainId(String trainId);

	void updateSeatAvailability(String seatId, boolean isAvailable);
}
