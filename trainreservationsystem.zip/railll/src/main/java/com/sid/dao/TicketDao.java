package com.sid.dao;

import java.util.List;

import com.sid.model.Ticket;

public interface TicketDao {
	Ticket createTicket(Ticket ticket);

	List<Ticket> getAllTickets();

	Ticket getTicket(int ticketId);

	Ticket updateTicket(int ticketId, Ticket ticket);

	String deleteTicket(int ticketId);

}
